package com.company;

import data.Grid;

public interface GridUtil1 {


    /**
     * Beinhaltet Methoden bezueglich der Transposition
     * von Gittern.
     *
     */

    //GridTransposition


     void transponse(Grid grid);
     boolean isTransposition(Grid grid1, Grid grid2);
}
